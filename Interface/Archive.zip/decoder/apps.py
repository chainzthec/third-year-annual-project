from django.apps import AppConfig


class FlagdecoderConfig(AppConfig):
    name = 'decoder'
